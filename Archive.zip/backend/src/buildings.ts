import { Router } from "express";
import { db } from "./db/index.ts";
import { buildings, rooms } from "./db/schema.ts";
import { eq } from "drizzle-orm";
import { getBuildingOccupancy, getRoomStatus } from "./serviceFunctions.ts";

const router = Router();

async function inBatches<T, R>(
  items: T[],
  batchSize: number,
  fn: (item: T) => Promise<R>,
): Promise<(R | null)[]> {
  const results: (R | null)[] = [];
  for (let i = 0; i < items.length; i += batchSize) {
    const settled = await Promise.allSettled(
      items.slice(i, i + batchSize).map(fn),
    );
    for (const s of settled) {
      results.push(s.status === "fulfilled" ? s.value : null);
    }
  }
  return results;
}

router.get("/", async (_req, res) => {
  try {
    const allBuildings = await db.select().from(buildings);

    const results = await inBatches(allBuildings, 10, async (building) => {
      const { occupancy, level, roomCount, freeCount } =
        await getBuildingOccupancy(building.id);
      return {
        id: building.id,
        name: building.name,
        code: building.code,
        latitude: building.latitude,
        longitude: building.longitude,
        occupancy,
        level,
        roomCount,
        freeCount,
        updatedAt: new Date().toISOString(),
      };
    });

    res.json(results.filter(Boolean));
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: "Failed to fetch buildings" });
  }
});

router.get("/:id/rooms", async (req, res) => {
  try {
    const buildingId = req.params.id;

    const buildingRooms = await db
      .select()
      .from(rooms)
      .where(eq(rooms.buildingId, buildingId));

    const results = await inBatches(buildingRooms, 10, async (room) => {
      const roomStatus = await getRoomStatus(room.id);
      return {
        id: room.id,
        number: room.number,
        type: room.type,
        capacity: room.capacity,
        status: roomStatus.status,
        ...("freesAt" in roomStatus && { freesAt: roomStatus.freesAt }),
        ...("freeUntil" in roomStatus && { freeUntil: roomStatus.freeUntil }),
        ...("courseName" in roomStatus &&
          roomStatus.courseName && { courseName: roomStatus.courseName }),
      };
    });

    res.json(results.filter(Boolean));
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: "Failed to fetch rooms" });
  }
});

export default router;

import type { Building, Room, RouteOption } from '../constants/mockData';

const BASE_URL = process.env.EXPO_PUBLIC_API_BASE_URL ?? 'http://10.110.129.176:3000';

export async function getBuildings(): Promise<Building[]> {
  const response = await fetch(`${BASE_URL}/api/buildings`);

  if (!response.ok) {
    throw new Error(`Failed to fetch buildings: ${response.status}`);
  }

  const data = await response.json();

  if (!Array.isArray(data)) {
    throw new Error("Invalid buildings response: expected array");
  }

  return data;
}

export async function getRooms(buildingId: string): Promise<Room[]> {
  const response = await fetch(`${BASE_URL}/api/buildings/${buildingId}/rooms`);

  if (!response.ok) {
    throw new Error(`Failed to fetch rooms: ${response.status}`);
  }

  const data = await response.json();

  if (!Array.isArray(data)) {
    throw new Error("Invalid rooms response: expected array");
  }

  return data;
}

export async function getRoutes(from: string, to: string): Promise<RouteOption[]> {
  const response = await fetch(`${BASE_URL}/api/routes?from=${from}&to=${to}`);

  if (!response.ok) {
    throw new Error(`Failed to fetch route: ${response.status}`);
  }

  const data = await response.json();

  if (!Array.isArray(data)) {
    throw new Error("Invalid routes response: expected array");
  }

  return data;
}

export async function getCampusGraph(): Promise<CampusGraphResponse> {
  const response = await fetch(`${BASE_URL}/api/campus-graph/latest`);

  if (!response.ok) {
    throw new Error(`Failed to fetch campus graph: ${response.status}`);
  }

  return response.json();
}

export async function getCampusGraphVersion(): Promise<CampusGraphVersion> {
  const response = await fetch(`${BASE_URL}/api/campus-graph/version`);

  if (!response.ok) {
    throw new Error(`Failed to fetch campus graph version: ${response.status}`);
  }

  return response.json();
}

export async function fetchClassSchedule(): Promise<ClassScheduleEntry[]> {
  const res = await fetch(`${BASE_URL}/api/schedules`); // TODO: restore once congestion is server-side
  if (!res.ok) {
    throw new Error("Failed to fetch schedule");
  }
  return res.json();
}


export async function getLibraryAvailability(query: LibraryAvailabilityQuery): Promise<LibraryRoomResult[]> {
  const params = new URLSearchParams({
    date: query.date,
    startTime: query.startTime,
    duration: String(query.duration),
    groupSize: String(query.groupSize),
    floor: query.floor,
    needsPower: String(query.needsPower),
    needsADA: String(query.needsADA),
  });

  console.log("Fetching library availability with params:", params.toString());
  const response = await fetch(`${BASE_URL}/api/library/availability?${params.toString()}`);
  console.log("Library availability response status:", response.status);

  if (!response.ok) {
    let message = `Failed to fetch library availability: ${response.status}`;

    try {
      console.warn("Attempting to parse error response from library availability API");
      const data = await response.json();
      console.warn("Parsed error response data:", data);
      if (data && typeof data.error === "string") {
        message = data.error;
      }
    } catch {
      // keep the status-based message
      console.warn("Failed to parse error response from library availability API");
      let text = await response.text();
      console.warn("Error response text:", text);
    }

    throw new Error(message);
  }
  
  console.log("Successfully fetched library availability");
  const data = await response.json();
  console.log("Library availability data:", data);

  if (!Array.isArray(data)) {
    throw new Error("Invalid library availability response: expected array");
  }

  return data;
}


export type ClassScheduleEntry = {
  id: string;
  roomId: string;
  buildingId: string;
  dayOfWeek: string;
  startTime: string;
  endTime: string;
  enrollment?: number;
};

export type CampusGraphVersion = {
  id: string;
  campusId: string;
  source: string;
  osmRelationId: string;
  fetchedAt: string | null;
  activatedAt: string | null;
};

export type CampusGraphNode = {
  id: string;
  graphVersionId: string;
  osmNodeId: string;
  lat: number;
  lng: number;
  type: string;
  label: string | null;
};

export type CampusGraphEdge = {
  id: string;
  graphVersionId: string;
  fromNodeId: string;
  toNodeId: string;
  distanceMeters: number;
  walkTimeSeconds: number;
  highwayType: string | null;
  surface: string | null;
  incline: string | null;
  isStairs: boolean;
  accessibilityPenalty: number;
  geometry: [number, number][];
};

export type CampusGraphResponse = {
  version: CampusGraphVersion;
  nodes: CampusGraphNode[];
  edges: CampusGraphEdge[];
};
export type LibraryAvailabilityQuery = {
  date: string;
  startTime: string;
  duration: number;
  groupSize: number;
  floor: string;
  needsPower: boolean;
  needsADA: boolean;
};

export type LibraryRoomResult = {
  id: number;
  eid: number;
  gid: number;
  lid: number;
  name: string;
  title: string;
  url: string;
  grouping: string;
  capacity: number;
  floor: string | null;
  hasPower: boolean;
  isADA: boolean;
  pageIndex: number;
  isAvailable: boolean;
  availableStarts: string[];
  nextAvailableStart: string | null;
  bookingUrl: string;
};